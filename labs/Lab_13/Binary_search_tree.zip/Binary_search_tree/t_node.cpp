#include "t_node.h"
template <typename T>
void Tnode <T>::PrintNodeInfo()
{
}
template <typename T>
Tnode <T> ::Tnode (const T& item,Tnode <T>,Tnode <T>*parentNode,Tnode <T>*leftNode,Tnode <T>*rightNode)
{
    nodeValue=item;
    //init value of node
    parent=parentNode;
    left=leftNode;
    right=rightNode;
}
