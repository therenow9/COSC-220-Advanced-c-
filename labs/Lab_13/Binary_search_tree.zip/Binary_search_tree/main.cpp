#include <iostream>
#include "t_node.h"
#include "functions.h"



using namespace std;

int main()
{
    BSTree<int> bt;
    // menu(bt);

    bt.BSTInsert(45);
    bt.BSTInsert(98);
    Tnode<int> *var=bt.getRoot();
    //InOrder(var);
    cout<<var->nodeValue;
    return 0;
}
