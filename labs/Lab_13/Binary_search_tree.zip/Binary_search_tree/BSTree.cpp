template <typename T>
void BSTree<T>::insert(Tnode<T>* &r,const T & item)
{
    Tnode <T>*curr=r;
    Tnode <T>* newNode;
    newNode->nodeValue=item;
    Tnode<T>* temp=NULL;
    //init

    while (curr!=NULL)
    {
        temp=curr;
        if (newNode->nodeValue<curr->nodeValue)
        {
            curr=curr->left;
            //set to left child
        }
        else
        {
            curr=curr->right;
        }
        //set parent to temp
    }
     newNode->parent=temp;
    if (temp==NULL)
    {
        root=newNode;
    }
    else if(newNode->nodeValue<temp->nodeValue)
    {
        temp->left=newNode;
    }
    else
    {
        temp->right=newNode;
    }
}
template <typename T>
void BSTree<T>::Delete(Tnode<T>* &r,const T & item)
{

}
template <typename T>
Tnode<T>* BSTree<T>::getRoot()
{
    return root;
}

//make root = null
template <typename T>
BSTree<T>::~BSTree()
{
    //call destructor
}
template <typename T>
void BSTree<T>::BSTInsert (const T & item)
{
   insert(root,item);


}

